﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APIREST.DAO.Models
{
    public class ContacteModel
    {
        public int contacteId;
        public string nom, cognoms;
        public List<TelefonModel> telefons = new List<TelefonModel>();

        public ContacteModel(int contacteId, string nom, string cognoms, List<TelefonModel> list)
        {
            this.contacteId = contacteId;
            this.nom = nom;
            this.cognoms = cognoms;
            this.telefons = list;
        }

        [JsonConstructor]
        public ContacteModel(int contacteId, string nom, string cognoms)
        {
            this.contacteId = contacteId;
            this.nom = nom;
            this.cognoms = cognoms;
        }
    }
}
