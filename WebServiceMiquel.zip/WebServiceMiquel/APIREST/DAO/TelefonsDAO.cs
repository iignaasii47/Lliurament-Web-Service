﻿using APIREST.DAO.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace APIREST.DAO
{
    public class TelefonsDAO
    {
        public static List<TelefonModel> readAll()
        {
            string queryString = "SELECT * FROM dbo.telefon;";
            SqlCommand cmd = new SqlCommand(queryString, Database.GetConnection());

            List<TelefonModel> list = new List<TelefonModel>();

            SqlDataReader reader = cmd.ExecuteReader();
            try
            {
                while (reader.Read())
                {
                    TelefonModel t = new TelefonModel(Int32.Parse(reader[0].ToString()), reader[1].ToString(),
                        reader[2].ToString(), Int32.Parse(reader[3].ToString()));
                    list.Add(t);
                }
            }
            finally
            {

                // Always call Close when done reading.
                reader.Close();
            }
            return list;
        }

        public static TelefonModel create(TelefonModel t)
        {
            string queryString = "INSERT INTO dbo.telefon(telefon, tipus, contacteId) OUTPUT inserted.telId, inserted.telefon, inserted.tipus, inserted.contacteId " +
                                   "values('" + t.telefon + "', '" + t.tipus + "', '" + t.contacteId + "');";

            SqlCommand cmd = new SqlCommand(queryString, Database.GetConnection());
            SqlDataReader reader = cmd.ExecuteReader();
            TelefonModel telefon = null;

            try
            {
                // TEST 
                while (reader.Read())
                {
                    telefon = new TelefonModel(Int32.Parse(reader[0].ToString()), reader[1].ToString(),
                        reader[2].ToString(), Int32.Parse(reader[3].ToString()));
                }
            }
            finally
            {
                // Always call Close when done reading.
                reader.Close();
            }

            return telefon;
        }

        public static TelefonModel update(TelefonModel t, int idTelefon)
        {
            string queryString = "UPDATE dbo.telefon SET tipus = '" + t.tipus + 
                "' , telefon = '"+t.telefon+"' , telefon.contacteId = "+t.contacteId +
                " OUTPUT inserted.telId, inserted.telefon, inserted.tipus, inserted.contacteId WHERE [telId] = " + idTelefon + ";";

            SqlCommand cmd = new SqlCommand(queryString, Database.GetConnection());
            TelefonModel telefon = null;
            SqlDataReader reader = cmd.ExecuteReader();

            try
            {
                while (reader.Read())
                {
                    telefon = new TelefonModel(Int32.Parse(reader[0].ToString()), reader[1].ToString(),
                        reader[2].ToString(), Int32.Parse(reader[3].ToString()));
                };
            }
            catch
            {

            }
            finally
            {
                reader.Close();
            }

            return telefon;
        }

        public static TelefonModel delete(int idTelefon)
        {
            string queryString = "DELETE from dbo.telefon where [telId] = "+idTelefon+";";

            SqlCommand cmd = new SqlCommand(queryString, Database.GetConnection());
            TelefonModel telefon = null;

            try
            {
                cmd.ExecuteReader();
            }
            catch
            {

            }

            return telefon;
        }
    }
}
