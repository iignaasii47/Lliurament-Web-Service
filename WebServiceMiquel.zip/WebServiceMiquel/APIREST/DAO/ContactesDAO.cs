﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using APIREST.DAO;

using System.Data;
using System.Data.SqlClient;
using APIREST.DAO.Models;

namespace APIREST.DAO
{
    public static class ContactesDAO
    {

        public static List<ContacteModel> readAll()
        {
            string queryString = "SELECT * FROM dbo.contacte;";
            SqlCommand cmd = new SqlCommand(queryString, Database.GetConnection());

            List<ContacteModel> list = new List<ContacteModel>();

            SqlDataReader reader = cmd.ExecuteReader();
            try
            {
                while (reader.Read())
                {
                    ContacteModel c = new ContacteModel(Int32.Parse(reader[0].ToString()), reader[1].ToString(), reader[2].ToString());
                    list.Add(c);
                }
            }
            finally
            {
           
                // Always call Close when done reading.
                reader.Close();
            }
            return list;
        }

        public static List<ContacteModel> readAllWithTelefons()
        {
            string queryString = "SELECT c.contacteId, c.nom, c.cognoms, t.telId as tid, t.telefon, t.tipus, t.contacteId FROM dbo.contacte c"+
                                " left join dbo.telefon t on t.contacteId = c.contacteId;";
            SqlCommand cmd = new SqlCommand(queryString, Database.GetConnection());

            List<ContacteModel> list = new List<ContacteModel>();

            SqlDataReader reader = cmd.ExecuteReader();
            try
            {
                while (reader.Read())
                {
                        var item = list.FirstOrDefault(c => c.contacteId == Int32.Parse(reader[0].ToString()));
                        if (item != null)
                        {
                            item.telefons.Add(new TelefonModel(Int32.Parse(reader[3].ToString()), reader[4].ToString(),
                               reader[5].ToString(), Int32.Parse(reader[6].ToString())));
                            continue;
                        }
                        ContacteModel cc = new ContacteModel(Int32.Parse(reader[0].ToString()), reader[1].ToString(), reader[2].ToString());
                        list.Add(cc);
                    }
            }
            finally
            {

                // Always call Close when done reading.
                reader.Close();
            }
            return list;
        }

        public static ContacteModel read(int id)
        {
            string queryString = "SELECT * FROM dbo.contacte where contacteId ="+ id +";";
            SqlCommand cmd = new SqlCommand(queryString, Database.GetConnection());
            SqlDataReader reader = cmd.ExecuteReader();

            ContacteModel c = null;
            try
            {
                while (reader.Read())
                {
                    c = new ContacteModel(Int32.Parse(reader[0].ToString()), reader[1].ToString(), reader[2].ToString());
                }
            }
            finally
            {

                // Always call Close when done reading.
                reader.Close();
            }
            return c;
        }

        public static ContacteModel readByPatro(string patro)

        {
            string queryString = "SELECT * FROM dbo.contacte where nom like '%" + patro + "%';";
            SqlCommand cmd = new SqlCommand(queryString, Database.GetConnection());
            SqlDataReader reader = cmd.ExecuteReader();

            ContacteModel c = null;
            try
            {
                while (reader.Read())
                {
                    c = new ContacteModel(Int32.Parse(reader[0].ToString()), reader[1].ToString(), reader[2].ToString());
                }
            }
            finally
            {

                // Always call Close when done reading.
                reader.Close();
            }
            return c;

        }

        public static List<ContacteModel> readByPhonePatro(string patro)

        {
            string queryString = "SELECT DISTINCT contacte.contacteId, contacte.nom FROM dbo.contacte " +
                                "inner join dbo.telefon t on t.contacteId = dbo.contacte.contacteId " +
                                "where t.telefon like '%"+ patro +"%';";
            SqlCommand cmd = new SqlCommand(queryString, Database.GetConnection());
            SqlDataReader reader = cmd.ExecuteReader();

            List<ContacteModel> list = new List<ContacteModel>();
            try
            {
                while (reader.Read())
                {
                   ContacteModel c = new ContacteModel(Int32.Parse(reader[0].ToString()), reader[1].ToString(), reader[2].ToString());
                    list.Add(c);
                }
            }
            finally
            {
                // Always call Close when done reading.
                reader.Close();
            }
            return list;

        }

        public static ContacteModel create(ContacteModel c)
        {
            string queryString = "INSERT INTO dbo.contacte (nom, cognoms) OUTPUT inserted.contacteId, inserted.nom, inserted.cognoms values ('" + c.nom + "', '"+c.cognoms+"');";

            SqlCommand cmd = new SqlCommand(queryString, Database.GetConnection());
            SqlDataReader reader = cmd.ExecuteReader();
            ContacteModel contacte = null;

            try
            {
                while (reader.Read())
                {
                    contacte = new ContacteModel(Int32.Parse(reader[0].ToString()), reader[1].ToString(), reader[2].ToString());
                }
            }
            finally
            {
                // Always call Close when done reading.
                reader.Close();
            }

            return contacte;
        }

        public static ContacteModel update(ContacteModel c, int idContacte)
        {
            string queryString = "UPDATE dbo.contacte SET nom = '"+c.nom+"', cognoms = '"+c.cognoms+ "' OUTPUT inserted.contacteId, inserted.nom, inserted.cognoms WHERE [contacteId] = " + idContacte + ";";

            SqlCommand cmd = new SqlCommand(queryString, Database.GetConnection());
            ContacteModel contacte = null;
            SqlDataReader reader = cmd.ExecuteReader();

            try
            {
                while (reader.Read())
                {
                    contacte = new ContacteModel(Int32.Parse(reader[0].ToString()), reader[1].ToString(), reader[2].ToString());
                };
            }
            catch
            {

            } finally
            {
                reader.Close();
            }

            return contacte;
        }

        public static ContacteModel delete(int idContacte)
        {
            string queryString = "DELETE from dbo.contacte where [contacteId] = " + idContacte + ";";

            SqlCommand cmd = new SqlCommand(queryString, Database.GetConnection());
            ContacteModel c = null;
            SqlDataReader reader = cmd.ExecuteReader();

            try
            {

            }
            catch
            {

            }finally
            {
                reader.Close();
            }

            return c;
        }
    }
}
