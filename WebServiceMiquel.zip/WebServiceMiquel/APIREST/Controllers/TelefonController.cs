﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using APIREST.DAO;
using APIREST.DAO.Models;
using Newtonsoft.Json;
using System.Net.Http;
using System.Web.Http;
using System.Net;

namespace APIREST.Controllers
{
    [Route("api/")]
    [ApiController]
    public class TelefonController : ControllerBase
    {
        [HttpGet("telefons")]
        public Object Get()
        {
            return JsonConvert.SerializeObject(TelefonsDAO.readAll(), formatting: Formatting.Indented);
        }

        [HttpPost("telefon")]
        public string Post( [FromBody] TelefonModel t)
        {
            return JsonConvert.SerializeObject(TelefonsDAO.create(t), formatting: Formatting.Indented);
        }

        // Update
        [HttpPut("telefon/{idtelefon}")]
        public Object Put(int idtelefon, [FromBody] TelefonModel t)
        {
            return JsonConvert.SerializeObject(TelefonsDAO.update(t, idtelefon), formatting: Formatting.Indented);
        }

        // Delete
        [HttpDelete("telefondel/{idtelefon}")]
        public Object Delete(int idtelefon)
        {
            return JsonConvert.SerializeObject(TelefonsDAO.delete(idtelefon), formatting: Formatting.Indented);
        }
    }
}