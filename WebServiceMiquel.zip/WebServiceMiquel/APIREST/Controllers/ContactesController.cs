﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using APIREST.DAO;
using APIREST.DAO.Models;
using Newtonsoft.Json;
using System.Net.Http;
using System.Net;
using System.IO;

namespace APIREST.Controllers
{
    [Route("api/")]
    [ApiController]
    public class ContactesController : ControllerBase
    {
        // GET: api/Contactes
        [HttpGet("contactes")]
        public String GetAll()
        {
            HttpWebResponse response = new HttpWebResponse();
            return JsonConvert.SerializeObject(ContactesDAO.readAll(), formatting: Formatting.Indented);
        }


        [HttpGet("contacte/{id}")]
        public Object Get(int id)
        {
            return JsonConvert.SerializeObject(ContactesDAO.read(id), formatting: Formatting.Indented);
        }

        [HttpGet("contactes/{patro}")]
        public Object GetByPatro(string patro)
        {
            return JsonConvert.SerializeObject(ContactesDAO.readByPatro(patro), formatting: Formatting.Indented);
        }

        [HttpGet("contactes/telefon/{patro}")]
        public Object GetByPhonePatro(string patro)
        {
            return JsonConvert.SerializeObject(ContactesDAO.readByPhonePatro(patro),formatting: Formatting.Indented);
        }

        [HttpGet("contactestot")]
        public Object GetTOt()
        {
            return JsonConvert.SerializeObject(ContactesDAO.readAllWithTelefons(), formatting: Formatting.Indented);
        }

        [HttpPost("contacte")]
        public Object Post([FromBody] ContacteModel c)
        {
            return JsonConvert.SerializeObject(ContactesDAO.create(c), formatting: Formatting.Indented);
        }

        // Update
        [HttpPut("contacte/{idcontacte}")]
        public Object Put(int idcontacte, [FromBody] ContacteModel c)
        {
            return JsonConvert.SerializeObject(ContactesDAO.update(c, idcontacte), formatting: Formatting.Indented);
        }

        // Delete
        [HttpDelete("contactedel/{idContacte}")]
        public Object Delete(int idContacte)
        {
            return JsonConvert.SerializeObject(ContactesDAO.delete(idContacte), formatting: Formatting.Indented);
        }
    }
}
