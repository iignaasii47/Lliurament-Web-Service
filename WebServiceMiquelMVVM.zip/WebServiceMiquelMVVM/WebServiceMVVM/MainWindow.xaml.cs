﻿using System;
using System.Net.Http;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using Newtonsoft.Json;

namespace WebServiceMVVM
{
    public partial class MainWindow : Window
    {
        private static readonly HttpClient client = new HttpClient();
        public MainWindow()
        {
            InitializeComponent();
        }

        private async void Button_GetAsync(object sender, RoutedEventArgs e)
        {
            string contactes = await client.GetStringAsync("http://localhost:49781/api/contactes");
            string telefons = await client.GetStringAsync("http://localhost:49781/api/telefons");

            var contactesData = JsonConvert.DeserializeObject<dynamic>(contactes);
            var telefonsData = JsonConvert.DeserializeObject<dynamic>(telefons);

            DG_Contactes.ItemsSource = contactesData;
            DG_Telefons.ItemsSource = telefonsData;

        }

        private async void Button_PostAsync(object sender, RoutedEventArgs e)
        {
            string myJson = 
                "{" +
                    "'nom': 'Fulano 42'," +
                    "'cognoms': 'csadfsdgwghwhwth'" +
                "}";
            var response = await client.PostAsync(
                "http://localhost:49781/api/contacte",
                new StringContent(myJson, Encoding.UTF8, "application/json"));
            Console.WriteLine(response);
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var win = new Window1();
            win.Show();
        }
    }
}
